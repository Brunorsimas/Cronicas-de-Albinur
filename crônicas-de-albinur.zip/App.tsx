
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './views/Home';
import StoryDetail from './views/StoryDetail';
import LiveChat from './components/LiveChat';
import { stories } from './constants';
import type { Story } from './types';

const App: React.FC = () => {
    const [currentStoryId, setCurrentStoryId] = useState<string | null>(null);

    const handleSelectStory = useCallback((story: Story) => {
        setCurrentStoryId(story.id);
    }, []);

    const handleGoHome = useCallback(() => {
        setCurrentStoryId(null);
    }, []);

    const currentStory = stories.find(s => s.id === currentStoryId);

    return (
        <div className="flex flex-col min-h-screen font-body">
            <Header onGoHome={handleGoHome} />
            <main className="flex-grow container mx-auto px-4 py-8">
                {currentStory ? (
                    <StoryDetail story={currentStory} onGoBack={handleGoHome} />
                ) : (
                    <Home onSelectStory={handleSelectStory} />
                )}
            </main>
            <Footer />
            <LiveChat />
        </div>
    );
};

export default App;
