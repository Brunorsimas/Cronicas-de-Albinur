export interface Character {
  name: string;
  title: string;
  personality: string;
  age: string;
  origin: string;
  race: string;
  description: string;
}

export interface Story {
  id: string;
  title: string;
  pageTitle: string;
  continentId: string;
  image: string;
  summary: string;
  content: string;
  character: Character;
}

export interface Continent {
  id: string;
  name: string;
  image: string;
  description: string;
}