import React, { useState } from 'react';
import StoryCard from '../components/StoryCard';
import { stories } from '../constants';
import type { Story } from '../types';
import { searchLore } from '../services/geminiService';

interface HomeProps {
    onSelectStory: (story: Story) => void;
}

const Home: React.FC<HomeProps> = ({ onSelectStory }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<{ text: string, sources: any[] } | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        setIsLoading(true);
        setSearchResults(null);
        try {
            const results = await searchLore(searchQuery);
            setSearchResults(results);
        } catch (error) {
            console.error("Search failed", error);
            setSearchResults({ text: "Desculpe, não foi possível encontrar informações sobre isso.", sources: [] });
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <>
            <section className="mb-12 text-center relative overflow-hidden rounded-lg shadow-md border-2 border-medieval-accent">
                <div className="relative w-full h-80 overflow-hidden">
                    <img src="Vhar'Zhul despertar.png" alt="Cenário medieval de Albinur" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black bg-opacity-40"></div>
                </div>
                <div className="absolute inset-0 flex flex-col justify-center items-center p-4">
                    <h1 className="font-title text-3xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">Onde Lendas São Forjadas</h1>
                    <p className="text-lg text-gray-200 drop-shadow-md">Explore contos de bravura, magia e mistério.</p>
                </div>
            </section>
            
            <section className="mb-12">
                 <h2 className="font-title text-3xl font-bold text-medieval-dark mb-4 border-b-2 border-medieval-accent pb-2">
                    Pesquisar as Crônicas
                </h2>
                <form onSubmit={handleSearch} className="flex gap-2 mb-4">
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Pergunte sobre a história de Albinur..."
                        className="flex-grow p-2 border border-medieval-accent rounded bg-medieval-card focus:outline-none focus:ring-2 focus:ring-medieval-accent"
                    />
                    <button type="submit" disabled={isLoading} className="bg-medieval-dark text-medieval-light px-6 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 font-semibold disabled:opacity-50">
                        {isLoading ? 'Buscando...' : 'Buscar'}
                    </button>
                </form>
                {searchResults && (
                    <div className="p-4 bg-medieval-card border border-medieval-accent rounded">
                        <p className="whitespace-pre-wrap">{searchResults.text}</p>
                        {searchResults.sources.length > 0 && (
                            <div className="mt-4">
                               <h4 className="font-bold text-sm text-medieval-dark">Fontes:</h4>
                               <ul className="list-disc list-inside text-sm">
                                  {searchResults.sources.map((source, index) => (
                                     <li key={index}>
                                         <a href={source.web?.uri} target="_blank" rel="noopener noreferrer" className="text-medieval-accent hover:underline">{source.web?.title || 'Fonte da Web'}</a>
                                     </li>
                                  ))}
                               </ul>
                            </div>
                        )}
                    </div>
                )}
            </section>

            <section>
                <h2 className="font-title text-3xl font-bold text-medieval-dark mb-6 border-b-2 border-medieval-accent pb-2">
                    Últimas Crônicas
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {stories.map(story => (
                        <StoryCard key={story.id} story={story} onSelectStory={onSelectStory} />
                    ))}
                </div>
            </section>
        </>
    );
};

export default Home;