import React, { useState, useEffect, useRef } from 'react';
import type { Story } from '../types';
import { generateSpeech, generateImage } from '../services/geminiService';

interface StoryDetailProps {
    story: Story;
    onGoBack: () => void;
}

// Helper to decode Base64
function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Helper to decode raw PCM audio data
async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / 1; // Mono channel
    const buffer = ctx.createBuffer(1, frameCount, 24000); // 24000 sample rate
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
}


const StoryDetail: React.FC<StoryDetailProps> = ({ story, onGoBack }) => {
    const [isReading, setIsReading] = useState(false);
    const [generatingImage, setGeneratingImage] = useState(false);
    const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    useEffect(() => {
        // Cleanup audio context on component unmount
        return () => {
            audioSourceRef.current?.stop();
            audioContextRef.current?.close();
        };
    }, []);

    const handleReadAloud = async () => {
        if (isReading) {
            audioSourceRef.current?.stop();
            setIsReading(false);
            return;
        }

        setIsReading(true);
        try {
            const storyText = story.content.replace(/###/g, '').replace(/%%IMAGE:[^%]+%%/g, ''); // Simple cleanup
            const audioB64 = await generateSpeech(storyText);
            
            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
            }
            const ctx = audioContextRef.current;
            const audioBytes = decode(audioB64);
            const audioBuffer = await decodeAudioData(audioBytes, ctx);
            
            audioSourceRef.current = ctx.createBufferSource();
            audioSourceRef.current.buffer = audioBuffer;
            audioSourceRef.current.connect(ctx.destination);
            audioSourceRef.current.onended = () => setIsReading(false);
            audioSourceRef.current.start();

        } catch (error) {
            console.error("Failed to read story aloud:", error);
            setIsReading(false);
        }
    };
    
    const handleGenerateImage = async () => {
        setGeneratingImage(true);
        setGeneratedImageUrl(null);
        try {
            const prompt = `A detailed medieval fantasy illustration of ${story.character.name}, ${story.character.title}. ${story.character.description}`;
            const imageB64 = await generateImage(prompt);
            setGeneratedImageUrl(`data:image/jpeg;base64,${imageB64}`);
        } catch (error) {
            console.error("Failed to generate image", error);
        } finally {
            setGeneratingImage(false);
        }
    }

    const renderContent = (content: string) => {
        const imageRegex = /%%IMAGE:([^|]+)\|([^|]+)\|([^%]+)%%/g;

        return content.split('\n').map((paragraph, index) => {
            if (paragraph.startsWith('### ')) {
                return <h3 key={index} className="font-title text-2xl font-bold text-medieval-dark mt-6 mb-3 text-center">{paragraph.substring(4)}</h3>;
            }

            const match = imageRegex.exec(paragraph);
            if (match) {
                const [, src, alt, widthClass] = match;
                return (
                    <div key={index} className="text-center my-6">
                        <img src={src} alt={alt} className={`inline-block rounded shadow-lg ${widthClass}`} />
                    </div>
                );
            }

            if (paragraph.trim() === '') return null;
            return <p key={index} className="mb-4 leading-relaxed text-gray-800 md:text-lg">{paragraph}</p>;
        });
    };

    return (
        <article className="max-w-3xl mx-auto bg-medieval-card border-2 border-medieval-accent p-6 md:p-8 rounded-lg shadow-xl">
            <h1 className="font-title text-4xl font-bold text-medieval-dark mb-6 text-center">{story.pageTitle}</h1>

            <section className="border border-medieval-accent rounded-lg p-4 mb-6 bg-opacity-50 bg-medieval-light">
                <h2 className="font-title text-2xl md:text-3xl font-bold text-medieval-dark mb-3 border-b-4 border-medieval-accent pb-2 text-center">
                    Detalhes do Personagem
                </h2>
                <dl className="text-sm md:text-base">
                    <div className="mb-1"><dt className="font-bold text-medieval-dark inline">Nome:</dt> <dd className="inline ml-1">{story.character.name} - {story.character.title}</dd></div>
                    <div className="mb-1"><dt className="font-bold text-medieval-dark inline">Personalidade:</dt> <dd className="inline ml-1">{story.character.personality}</dd></div>
                    <div className="mb-1"><dt className="font-bold text-medieval-dark inline">Idade:</dt> <dd className="inline ml-1">{story.character.age}</dd></div>
                    <div className="mb-1"><dt className="font-bold text-medieval-dark inline">Origem:</dt> <dd className="inline ml-1">{story.character.origin}</dd></div>
                    <div className="mb-1"><dt className="font-bold text-medieval-dark inline">Raça:</dt> <dd className="inline ml-1">{story.character.race}</dd></div>
                </dl>
                <h3 className="font-title text-xl md:text-2xl font-bold text-medieval-dark mt-4 mb-2 text-center">Descrição:</h3>
                <p className="text-sm md:text-base text-gray-700 text-justify">{story.character.description}</p>
            </section>
            
            <div className="flex flex-col sm:flex-row gap-4 my-6 justify-center">
                 <button onClick={handleReadAloud} disabled={isReading} className="bg-medieval-dark text-medieval-light px-6 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 font-semibold disabled:opacity-50">
                    {isReading ? 'Parar Leitura' : 'Ler em Voz Alta'}
                </button>
                <button onClick={handleGenerateImage} disabled={generatingImage} className="bg-medieval-dark text-medieval-light px-6 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 font-semibold disabled:opacity-50">
                    {generatingImage ? 'Visualizando...' : `Visualizar ${story.character.name}`}
                </button>
            </div>

            {generatedImageUrl && (
                <div className="my-6 border-2 border-medieval-accent p-2 rounded-lg">
                    <img src={generatedImageUrl} alt={`Visualização de ${story.character.name}`} className="w-full h-auto object-contain rounded"/>
                </div>
            )}
            
            <section className="story-content text-justify mt-8">
                {renderContent(story.content)}
            </section>

            <div className="mt-10 text-center">
                <button
                    onClick={onGoBack}
                    className="inline-block bg-medieval-dark text-medieval-light px-6 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 font-semibold"
                >
                    &larr; Voltar para Histórias
                </button>
            </div>
        </article>
    );
};

export default StoryDetail;