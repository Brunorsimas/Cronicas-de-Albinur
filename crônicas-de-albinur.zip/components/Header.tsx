
import React, { useState } from 'react';

interface HeaderProps {
    onGoHome: () => void;
}

const Header: React.FC<HeaderProps> = ({ onGoHome }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navLinks = [
        { name: 'Início', action: onGoHome },
        { name: 'Histórias', action: onGoHome },
        { name: 'Categorias', action: () => {} },
        { name: 'Sobre', action: () => {} },
        { name: 'Contato', action: () => {} },
    ];

    return (
        <header className="bg-medieval-dark text-medieval-light shadow-lg sticky top-0 z-50">
            <div className="container mx-auto px-4 py-3 flex justify-between items-center">
                <button
                    onClick={onGoHome}
                    className="font-title text-2xl lg:text-3xl font-bold hover:text-medieval-accent transition duration-300"
                >
                    Crônicas De Albinur
                </button>
                <nav>
                    <button id="menu-btn" className="md:hidden text-medieval-light focus:outline-none" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                        </svg>
                    </button>
                    <ul id="menu" className="hidden md:flex space-x-6 font-title items-center">
                        {navLinks.map((link) => (
                            <li key={link.name}>
                                <button onClick={link.action} className="hover:text-medieval-accent transition duration-300">{link.name}</button>
                            </li>
                        ))}
                    </ul>
                </nav>
            </div>
            {isMenuOpen && (
                <div id="mobile-menu" className="md:hidden bg-medieval-dark text-center py-2">
                    {navLinks.map((link) => (
                        <button key={link.name} onClick={link.action} className="block w-full py-2 px-4 text-sm hover:bg-medieval-accent hover:text-medieval-dark transition duration-300">
                            {link.name}
                        </button>
                    ))}
                </div>
            )}
        </header>
    );
};

export default Header;
