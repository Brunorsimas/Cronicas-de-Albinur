
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-medieval-dark text-medieval-light mt-12 py-6">
            <div className="container mx-auto px-4 text-center text-sm">
                <p>© 2025 Crônicas De Albinur. Todos os direitos reservados.</p>
                <p className="mt-1">Um portal para aventuras de outrora.</p>
            </div>
        </footer>
    );
};

export default Footer;
