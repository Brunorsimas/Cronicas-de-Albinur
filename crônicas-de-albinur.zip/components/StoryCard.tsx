
import React from 'react';
import type { Story } from '../types';

interface StoryCardProps {
    story: Story;
    onSelectStory: (story: Story) => void;
}

const StoryCard: React.FC<StoryCardProps> = ({ story, onSelectStory }) => {
    return (
        <article className="bg-medieval-card rounded-lg shadow-md overflow-hidden border border-medieval-accent transform hover:scale-105 transition duration-300 flex flex-col">
            <img src={story.image.replace('800/450', '600/400')} alt={`Imagem representando ${story.title}`} className="w-full h-48 object-cover" />
            <div className="p-6 flex-grow flex flex-col">
                <h3 className="font-title text-xl font-bold mb-2 text-medieval-dark">{story.title}</h3>
                <p className="text-sm text-gray-600 mb-4 line-clamp-3 flex-grow">{story.summary}</p>
                <button
                    onClick={() => onSelectStory(story)}
                    className="self-start mt-auto inline-block bg-medieval-dark text-medieval-light px-4 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 text-sm font-semibold"
                >
                    Ler Mais
                </button>
            </div>
        </article>
    );
};

export default StoryCard;
