
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { getLiveSession } from '../services/geminiService';
import type { LiveSession, LiveServerMessage, Blob } from '@google/genai';

// Helper functions for audio encoding/decoding
function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}


const LiveChat: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isLive, setIsLive] = useState(false);
    const [status, setStatus] = useState('Idle');
    const [transcripts, setTranscripts] = useState<{ user: string; model: string }[]>([]);
    
    const sessionPromise = useRef<Promise<LiveSession> | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const nextStartTime = useRef(0);
    const sources = useRef(new Set<AudioBufferSourceNode>());

    const currentInputTranscription = useRef('');
    const currentOutputTranscription = useRef('');

    const startConversation = useCallback(async () => {
        if (isLive) return;

        try {
            setStatus('Connecting...');
            const hasPermission = await navigator.mediaDevices.getUserMedia({ audio: true });
            if (!hasPermission) {
                setStatus('Microphone permission denied.');
                return;
            }
            streamRef.current = hasPermission;

            const ai = getLiveSession();
            
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sessionPromise.current = ai.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        setStatus('Listening...');
                        setIsLive(true);

                        inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                        sourceNodeRef.current = inputAudioContextRef.current.createMediaStreamSource(streamRef.current!);
                        scriptProcessorRef.current = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
                        
                        scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob: Blob = {
                                data: encode(new Uint8Array(new Int16Array(inputData.map(x => x * 32768)).buffer)),
                                mimeType: 'audio/pcm;rate=16000',
                            };
                            
                            if (sessionPromise.current) {
                                sessionPromise.current.then((session) => {
                                    session.sendRealtimeInput({ media: pcmBlob });
                                });
                            }
                        };
                        sourceNodeRef.current.connect(scriptProcessorRef.current);
                        scriptProcessorRef.current.connect(inputAudioContextRef.current.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                       if (message.serverContent?.inputTranscription) {
                            currentInputTranscription.current += message.serverContent.inputTranscription.text;
                        }
                        if (message.serverContent?.outputTranscription) {
                            currentOutputTranscription.current += message.serverContent.outputTranscription.text;
                        }
                        if (message.serverContent?.turnComplete) {
                            const fullInput = currentInputTranscription.current;
                            const fullOutput = currentOutputTranscription.current;
                            setTranscripts(prev => [...prev, { user: fullInput, model: fullOutput }]);
                            currentInputTranscription.current = '';
                            currentOutputTranscription.current = '';
                        }

                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio && outputAudioContextRef.current) {
                            setStatus('Speaking...');
                            const outputCtx = outputAudioContextRef.current;
                            nextStartTime.current = Math.max(nextStartTime.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            source.addEventListener('ended', () => {
                                sources.current.delete(source);
                                if (sources.current.size === 0) {
                                    setStatus('Listening...');
                                }
                            });
                            source.start(nextStartTime.current);
                            nextStartTime.current += audioBuffer.duration;
                            sources.current.add(source);
                        }

                        if (message.serverContent?.interrupted) {
                            sources.current.forEach(source => source.stop());
                            sources.current.clear();
                            nextStartTime.current = 0;
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Live API Error:', e);
                        setStatus(`Error: ${e.message}`);
                        stopConversation();
                    },
                    onclose: () => {
                        setStatus('Connection closed.');
                        stopConversation();
                    },
                },
                config: {
                    responseModalities: ['AUDIO'],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    systemInstruction: 'You are a wise old loremaster from the fantasy world of Albinur. Speak with an epic and slightly archaic tone. Answer questions about the world, its characters, and its history.',
                },
            });

        } catch (error) {
            console.error('Failed to start conversation:', error);
            setStatus('Failed to start. Check permissions.');
        }
    }, [isLive]);

    const stopConversation = useCallback(async () => {
        if (sessionPromise.current) {
            const session = await sessionPromise.current;
            session.close();
            sessionPromise.current = null;
        }

        scriptProcessorRef.current?.disconnect();
        sourceNodeRef.current?.disconnect();
        streamRef.current?.getTracks().forEach(track => track.stop());
        
        inputAudioContextRef.current?.close();
        outputAudioContextRef.current?.close();
        
        scriptProcessorRef.current = null;
        sourceNodeRef.current = null;
        streamRef.current = null;
        inputAudioContextRef.current = null;
        outputAudioContextRef.current = null;

        sources.current.forEach(source => source.stop());
        sources.current.clear();
        nextStartTime.current = 0;
        
        setIsLive(false);
        setStatus('Idle');
    }, []);

    useEffect(() => {
        return () => {
            if(isLive) stopConversation();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    return (
        <>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="fixed bottom-6 right-6 bg-medieval-accent text-medieval-dark p-4 rounded-full shadow-lg hover:bg-medieval-dark hover:text-medieval-accent transition-transform transform hover:scale-110 z-50"
                aria-label="Open AI Chat"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.486 2 2 5.589 2 10c0 2.908 1.897 5.515 4.675 6.918.254.103.325.399.325.666v1.916c0 .543.583.927 1.07.648C9.538 19.332 10.74 19 12 19c5.514 0 10-3.589 10-9s-4.486-8-10-8zm0 15c-1.12 0-2.182-.294-3.11-.822-.163-.09-.37-.028-.448.125l-.71 1.42C7.26 18.57 6.474 19.46 5.5 20c-1.18 0-2.22-1-3-2 .55-.25 1-1 1-2s-1-2-1-2-1 3-2 3c-1 0-1.5-.5-2-1 .5-1 1-2.5 1-4 0-3.86 3.582-7 8-7s8 3.14 8 7-3.582 7-8 7z"/></svg>
            </button>

            {isOpen && (
                <div className="fixed bottom-24 right-6 w-full max-w-sm h-2/3 bg-medieval-card border-2 border-medieval-accent rounded-lg shadow-2xl z-50 flex flex-col font-body">
                    <div className="p-3 bg-medieval-dark text-medieval-light rounded-t-lg flex justify-between items-center">
                        <h3 className="font-title font-bold">Converse com o Mestre do Conhecimento</h3>
                        <button onClick={() => setIsOpen(false)} className="text-medieval-light hover:text-medieval-accent">&times;</button>
                    </div>

                    <div className="flex-grow p-4 overflow-y-auto space-y-4">
                        {transcripts.map((t, i) => (
                            <div key={i}>
                                <p className="text-sm text-medieval-accent font-bold">Você:</p>
                                <p className="text-gray-700 italic">"{t.user}"</p>
                                <p className="text-sm text-medieval-dark font-bold mt-2">Mestre:</p>
                                <p className="text-gray-800">"{t.model}"</p>
                            </div>
                        ))}
                         {transcripts.length === 0 && <p className="text-center text-gray-500 italic">Comece a conversa com o Mestre do Conhecimento de Albinur...</p>}
                    </div>

                    <div className="p-3 border-t border-medieval-accent bg-medieval-light rounded-b-lg">
                        <div className="text-center font-bold text-medieval-dark mb-2">{status}</div>
                        {!isLive ? (
                            <button onClick={startConversation} className="w-full bg-medieval-dark text-medieval-light px-4 py-2 rounded hover:bg-medieval-accent hover:text-medieval-dark transition duration-300 font-semibold">
                                Iniciar Conversa
                            </button>
                        ) : (
                            <button onClick={stopConversation} className="w-full bg-red-800 text-medieval-light px-4 py-2 rounded hover:bg-red-900 transition duration-300 font-semibold">
                                Encerrar Conversa
                            </button>
                        )}
                    </div>
                </div>
            )}
        </>
    );
};

export default LiveChat;
